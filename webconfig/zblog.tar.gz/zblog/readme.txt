﻿Z-BlogPHP安装说明

1.Z-BlogPHP需要PHP 5.2及以上版本的PHP环境。
2.支持IIS,Apache,Lighttpd,Nginx等Web服务器。
3.上传Z-BlogPHP。
4.打开http://你的网站/。
5.同意Z-Blog许可协议。
6.建立数据库
    Z-BlogPHP支持MySQL以及SQLite数据库。具体您该使用哪一种需要参考空间配置。
    一般情况下选择MySQL数据库，输入空间商为您提供的MySQL帐号密码。
    或是使用单数据库的SQLite，程序将自动创建。
    然后输入你为站点设置的管理员帐号密码。
7.安装成功，进入网站。
8.安装完成后请删除zb_install文件夹。
9.系统默认集成的是UEditor编辑器，如需Markdown，KindEditor等请到应用中心搜索并安装。